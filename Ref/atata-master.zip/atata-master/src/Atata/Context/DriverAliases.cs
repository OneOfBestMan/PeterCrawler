﻿namespace Atata
{
    public static class DriverAliases
    {
        public const string Remote = "remote";

        public const string Chrome = "chrome";

        public const string Firefox = "firefox";

        public const string InternetExplorer = "internetexplorer";

        public const string Safari = "safari";

        public const string Opera = "opera";

        public const string Edge = "edge";

        public const string PhantomJS = "phantomjs";
    }
}
