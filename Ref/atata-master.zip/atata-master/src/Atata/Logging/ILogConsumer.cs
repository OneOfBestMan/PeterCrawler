﻿namespace Atata
{
    public interface ILogConsumer
    {
        void Log(LogEventInfo eventInfo);
    }
}
