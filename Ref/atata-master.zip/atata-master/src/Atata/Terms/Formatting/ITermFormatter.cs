﻿namespace Atata.TermFormatting
{
    public interface ITermFormatter
    {
        string Format(string[] words);
    }
}
