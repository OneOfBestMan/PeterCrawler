﻿namespace Atata
{
    public enum FindTermBy
    {
        Id,
        Name,
        Class,
        Label,
        Content,
        Value,
        ContentOrValue,
        ColumnHeader,
        Title,
        FieldSet,
        Placeholder,
        DescriptionTerm,
        ChildContent
    }
}
