﻿namespace Atata
{
    public class MissingComponentScopeLocateResult : ComponentScopeLocateResult
    {
        public MissingComponentScopeLocateResult()
        {
        }
    }
}
