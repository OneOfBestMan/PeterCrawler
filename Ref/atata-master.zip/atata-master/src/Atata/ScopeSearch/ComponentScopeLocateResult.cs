﻿namespace Atata
{
    // TODO: Review ComponentScopeLocateResult class.
    public abstract class ComponentScopeLocateResult
    {
    }
}
