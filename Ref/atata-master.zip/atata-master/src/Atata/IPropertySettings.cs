﻿namespace Atata
{
    public interface IPropertySettings
    {
        PropertyBag Properties { get; }
    }
}
