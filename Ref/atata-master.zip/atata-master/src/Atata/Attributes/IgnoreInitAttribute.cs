﻿using System;

namespace Atata
{
    [AttributeUsage(AttributeTargets.Property)]
    public class IgnoreInitAttribute : Attribute
    {
    }
}
