﻿namespace Atata
{
    public class WindowTitleElementDefinitionAttribute : ScopeDefinitionAttribute
    {
        public WindowTitleElementDefinitionAttribute(string scopeXPath = null)
            : base(scopeXPath)
        {
        }
    }
}
