﻿namespace Atata
{
    public class ItemValueXPathAttribute : ExtraXPathAttribute
    {
        public ItemValueXPathAttribute(string xPath)
            : base(xPath)
        {
        }
    }
}
