﻿namespace Atata
{
    public interface IItemsControl
    {
        void Apply(IItemElementFindStrategy itemElementFindStrategy);
    }
}
