﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Yevgeniy Shunevych")]
[assembly: AssemblyProduct("Atata Framework")]
[assembly: AssemblyCopyright("Copyright © Yevgeniy Shunevych 2017")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("0.15.0")]
[assembly: AssemblyFileVersion("0.15.0")]
