﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Atata.Tests")]
[assembly: Guid("9d0aa4f2-4987-4395-be95-76abc329b7a0")]
