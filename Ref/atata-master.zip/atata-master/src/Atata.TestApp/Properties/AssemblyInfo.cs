﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Atata.TestApp")]
[assembly: Guid("b756dea6-2566-44a1-8f8b-fc672500afc6")]
