# 编译说明:
	1.成功编译这个解决方案至少需要安装.Net framework 3.5 sp1.
	  下载地址:http://download.microsoft.com/download/2/0/E/20E90413-712F-438C-988E-FDAA79A8AC3D/dotnetfx35.exe
	2.如果未安装Visual Studio开发工具,运行MSBuild.bat批处理也可以编译项目文件.
	3.应用程序启动位置:SmartSpider\bin\Debug\SmartSpider.exe

# 项目升级
该项目已无升级计划，请同学们移步至集群版：
SmartSpiderCluster：https://github.com/ljja/SmartSpiderCluster

# 沟通交流
SmartSpider开源项目交流群开通啦！QQ群号：229853793(SmartSpider)

# 软件截图
## 启动界面
![启动界面](https://raw.githubusercontent.com/smartbooks/SmartSpider/master/doc/run-boot.png)

## 软件主界面
![软件主界面](https://raw.githubusercontent.com/smartbooks/SmartSpider/master/doc/run-main.png)

## 新建采集任务
![新建采集任务](https://raw.githubusercontent.com/smartbooks/SmartSpider/master/doc/run-task-new.png)

## 运行采集任务
![运行采集任务](https://raw.githubusercontent.com/smartbooks/SmartSpider/master/doc/run-runtime.png)

## 软件配置
![软件配置](https://raw.githubusercontent.com/smartbooks/SmartSpider/master/doc/run-option.png)

## 手工配置
![手工配置](https://raw.githubusercontent.com/smartbooks/SmartSpider/master/doc/run-config-example.png)
