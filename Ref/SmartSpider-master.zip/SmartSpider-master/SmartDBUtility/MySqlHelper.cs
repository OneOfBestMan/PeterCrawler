﻿
namespace Smart.DBUtility
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public abstract class MySqlHelper
    {
    }
}
