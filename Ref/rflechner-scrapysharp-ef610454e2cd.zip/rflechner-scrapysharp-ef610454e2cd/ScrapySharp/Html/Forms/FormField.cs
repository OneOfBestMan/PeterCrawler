namespace ScrapySharp.Html.Forms
{
    public class FormField
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}