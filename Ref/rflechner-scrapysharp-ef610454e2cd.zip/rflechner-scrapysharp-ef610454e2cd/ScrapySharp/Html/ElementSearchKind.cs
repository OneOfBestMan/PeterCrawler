namespace ScrapySharp.Html
{
    public enum ElementSearchKind
    {
        Text,
        Id,
        Name,
        Class
    }
}