namespace ScrapySharp.Html.Dom
{
    public interface IHSubContainer
    {
        
    }
}