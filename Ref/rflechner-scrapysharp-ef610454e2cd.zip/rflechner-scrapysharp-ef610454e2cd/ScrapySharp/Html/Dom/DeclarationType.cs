namespace ScrapySharp.Html.Dom
{
    public enum DeclarationType
    {
        TextElement,
        OpenTag,
        CloseTag,
        SelfClosedTag,
        Comment,
    }
}