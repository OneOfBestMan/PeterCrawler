﻿namespace ScrapySharp.Network
{
    public enum HttpVerb
    {
        Get,
		Head,
		Post,
		Put,
		Delete,
		Trace,
		Options
	}
}