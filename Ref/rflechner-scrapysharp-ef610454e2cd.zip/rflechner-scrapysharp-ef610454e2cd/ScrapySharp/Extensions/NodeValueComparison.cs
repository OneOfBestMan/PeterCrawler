﻿namespace ScrapySharp.Extensions
{
    public enum NodeValueComparison
    {
        Equals,
        StartsWith,
        EndsWith,
        Contains
    }
}