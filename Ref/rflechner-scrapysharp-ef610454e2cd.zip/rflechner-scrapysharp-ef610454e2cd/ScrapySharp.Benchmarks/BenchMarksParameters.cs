namespace ScrapySharp.Benchmarks
{
    internal class BenchMarksParameters
    {
        public const int Iterations = 1;
    }
}