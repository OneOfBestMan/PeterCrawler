﻿namespace Selenium.core.browsers
{
    public enum BrowserType
    {
        Firefox,
        Chrome,
        Remote
    }
}