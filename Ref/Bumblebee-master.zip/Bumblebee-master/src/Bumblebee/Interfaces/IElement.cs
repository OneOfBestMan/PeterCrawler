﻿namespace Bumblebee.Interfaces
{
	public interface IElement : IDraggable, IHasSession
	{
	}
}
