namespace Bumblebee.Interfaces
{
	public interface IBlock : IElement, IMonkeyable
	{
	}
}
