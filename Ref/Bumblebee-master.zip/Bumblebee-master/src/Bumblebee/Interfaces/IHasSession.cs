using Bumblebee.Setup;

namespace Bumblebee.Interfaces
{
	public interface IHasSession
	{
		Session Session { get; }
	}
}
