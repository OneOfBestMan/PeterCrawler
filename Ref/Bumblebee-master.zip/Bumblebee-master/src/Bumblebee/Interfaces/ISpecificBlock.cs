namespace Bumblebee.Interfaces
{
	public interface ISpecificBlock
	{
	}
}
