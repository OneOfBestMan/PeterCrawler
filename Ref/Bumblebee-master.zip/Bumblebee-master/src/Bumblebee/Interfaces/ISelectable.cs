﻿namespace Bumblebee.Interfaces
{
	public interface ISelectable
	{
		bool Selected { get; }
	}
}
