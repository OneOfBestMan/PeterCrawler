﻿namespace Bumblebee.Interfaces
{
	public interface IMonkeyable
	{
		void VerifyMonkeyState();
	}
}
