﻿namespace Bumblebee.Interfaces
{
	public interface IHasText
	{
		string Text { get; }
	}
}
