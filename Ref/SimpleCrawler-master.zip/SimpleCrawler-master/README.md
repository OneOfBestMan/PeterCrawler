# SimpleCrawler
C# Crawler 多线程爬虫程序，支持正则表达式过滤、关键字过滤、正文内容识别等等
