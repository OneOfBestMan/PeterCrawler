﻿
*.exe url encoding sleep

*.exe http://bj.qu114.com/ utf-8 50