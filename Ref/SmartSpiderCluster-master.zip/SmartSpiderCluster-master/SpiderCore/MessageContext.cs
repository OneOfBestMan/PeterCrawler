﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpiderCore
{
    public abstract class MessageContext
    {
        public Response Response { get; set; }
    }
}
