﻿namespace SpiderCore
{
    public class HtmlResponse : Response
    {
        public string Html { get; set; }
    }
}
