﻿using System.Threading;

namespace DotnetSpider.Extension.Test
{
	public class TestBase
	{
	}
}
