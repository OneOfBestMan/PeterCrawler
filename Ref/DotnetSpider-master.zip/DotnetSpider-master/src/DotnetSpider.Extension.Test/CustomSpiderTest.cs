﻿namespace DotnetSpider.Extension.Test
{
	public class CommonSpiderTest
	{
	}
}
