﻿namespace DotnetSpider.Core
{
	public interface IIdentity
	{
		string Identity { get; set; }
	}
}
