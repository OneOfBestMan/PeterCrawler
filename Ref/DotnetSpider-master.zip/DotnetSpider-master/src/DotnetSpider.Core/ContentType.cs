﻿namespace DotnetSpider.Core
{
	public enum ContentType
	{
		Auto,
		Html,
		Json,
		File
	}
}
