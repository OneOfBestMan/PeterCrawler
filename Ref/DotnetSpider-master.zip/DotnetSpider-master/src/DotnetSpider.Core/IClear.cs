﻿namespace DotnetSpider.Core
{
	public interface IClear
	{
		void Clear();
	}
}
