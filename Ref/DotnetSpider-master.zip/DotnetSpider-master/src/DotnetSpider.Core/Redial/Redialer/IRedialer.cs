﻿namespace DotnetSpider.Core.Redial.Redialer
{
	public interface IRedialer
	{
		void Redial();
	}
}
