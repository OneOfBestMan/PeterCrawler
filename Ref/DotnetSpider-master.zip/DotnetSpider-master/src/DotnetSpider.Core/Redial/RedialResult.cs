﻿namespace DotnetSpider.Core.Redial
{
	public enum RedialResult
	{
		Failed,
		Sucess,
		Skip,
		OtherRedialed
	}
}
