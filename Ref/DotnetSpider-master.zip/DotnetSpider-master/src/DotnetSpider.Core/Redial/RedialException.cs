﻿namespace DotnetSpider.Core.Redial
{
	public class RedialException : SpiderException
	{
		public RedialException(string message) : base(message)
		{
		}
	}
}
