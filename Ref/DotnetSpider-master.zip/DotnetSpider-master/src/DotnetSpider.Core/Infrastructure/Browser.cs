﻿namespace DotnetSpider.Core.Infrastructure
{
	public enum Browser
	{
		Firefox,
		Phantomjs,
		Chrome,
		Edge
	}
}
