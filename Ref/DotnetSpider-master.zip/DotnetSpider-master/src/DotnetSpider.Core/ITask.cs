﻿namespace DotnetSpider.Core
{
	public interface ITask
	{
		string TaskId { get; set; }
	}
}
